from django import forms

class sumaForm(forms.Form):
    a=forms.CharField()
    b=forms.CharField()
