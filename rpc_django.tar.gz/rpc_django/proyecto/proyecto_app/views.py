from django.shortcuts import render
from xmlrpc.client import ServerProxy
from django import forms
from .forms import sumaForm
from .models import Signo

# Create your views here.



def principal (request):
    return render(request,'index_horoscopo.html')

def muestra(request):
    obj = Signo.objects.all()

    for hor in obj:

        obj.id_signo      = hor.id_signo
        obj.nombre        = hor.nombre
        obj.personalidad  = hor.personalidad
        obj.color         = hor.color
        obj.elemento      = hor.elemento
        obj.simboliza     = hor.simboliza
        obj.semanal       = hor.semanal

        context={
        "obj"   :   obj,
        "obj.id_signo"  :   obj.id_signo,
        "obj.nombre"    :   obj.nombre,
        "obj.personalidad"  :   obj.personalidad,
        "obj.color" :   obj.color,
        "obj.elemento"  :   obj.elemento,
        "obj.simboliza" :   obj.simboliza,
        "obj.semanal"   :   obj.semanal,
        }
        return render(request,'muestra.html',context)

#Llamada a procedimiento remoto, ejemplo simple
def rpcAdd(resquest,a,b):
    client = ServerProxy('http://localhost:8000/rpc/')
    result = client.add(a, b)
    return  render(resquest,'rpcAdd.html',{'result':result})
#vista para el formulario
def get_suma(request):
    #se establece el metodo de respuesta
    if request.method == 'POST':
        #se crea un objeto de sumaForm
        form = sumaForm(request.POST)
        #se verifica que el formulario sea valido
        if form.is_valid():
            #obtiene los datos ingresados por el formulario
            data1 = form.cleaned_data['a']
            data2 = form.cleaned_data['b']
            #Transforma los datos a Flotante
            a=float('0' + data1)
            b=float('0' + data2)
            #{'form':form,'mydata':data1}
            #Crea un objeto remoto
            client = ServerProxy('http://localhost:8000/rpc/')
            #obtiene el resultado de llamar al metodo add
            resulta = client.add(a, b)
            return render(request,'index.html',{'form':form,'resulta':resulta })
    else:
        form = sumaForm()
    arg={'form':form}
    return render(request,'index.html',arg)
