# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

class Comparativa(models.Model):
    id_comp = models.IntegerField()
    elementos = models.CharField(max_length=30)
    analisis = models.TextField()

    class Meta:
        db_table = 'comparativa'

class Galleta(models.Model):
    mensaje = models.CharField(max_length=300)

    class Meta:
        db_table = 'galleta'


class Presentacion(models.Model):
    id = models.IntegerField(primary_key=True)
    saludo = models.TextField()

    class Meta:
        db_table = 'presentacion'


class Signo(models.Model):
    id_signo = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=50)
    personalidad = models.TextField()
    color = models.CharField(max_length=40)
    elemento = models.CharField(max_length=10)
    simboliza = models.TextField()
    semanal = models.TextField()

    class Meta:
        db_table = 'signo'


class SignoChino(models.Model):
    nombre = models.CharField(max_length=40)
    descripcion = models.TextField()
    planeta = models.CharField(max_length=15)
    elemento = models.CharField(max_length=15)
    hora_influencia = models.CharField(max_length=50)
    signo_equivalente = models.CharField(max_length=50)
    personalidad = models.TextField()
    signo_compatible = models.CharField(max_length=100)

    class Meta:
        db_table = 'signo_chino'
