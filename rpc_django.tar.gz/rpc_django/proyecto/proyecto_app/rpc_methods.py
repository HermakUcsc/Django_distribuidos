from modernrpc.core import rpc_method
@rpc_method
def add(a,b):
    if(a>=20 and b==1) or (a<=19 and b==2):
        return "Acuario"
    elif(a>=20 and b==2) or(a<=20 and b==3):
        return "Picis"
    elif(a>=21 and b==3) or(a<=20 and b==4):
        return "Aries"
    elif(a>=21 and b==4) or(a<=20 and b==5):
        return "Tauro"
    elif(a>=21 and b==5) or(a<=21 and b==6):
        return "Geminis"
    elif(a>=22 and b==6) or(a<=22 and b==7):
        return "Cáncer"
    elif(a>=23 and b==7) or(a<=23 and b==8):
        return "Leo"
    elif(a>=24 and b==8) or(a<=23 and b==9):
        return "Virgo"
    elif(a>=24 and b==9) or(a<=22 and b==10):
        return "Libra"
    elif(a>=23 and b==10) or(a<=22 and b==11):
        return "Escorpión"
    elif(a>=23 and b==11) or(a<=21 and b==12):
        return "Sagitario"
    elif(a>=22 and b==12) or(a<=19 and b==1):
        return "Capricornio"
